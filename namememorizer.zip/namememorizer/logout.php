<?php
session_register_shutdown();
header("Location: index.php");
