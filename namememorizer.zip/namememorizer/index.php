<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8">
	<title>Name Memorizer</title>
	<script type="text/javascript" src="namemmrz.js"></script>
	<link rel="stylesheet" type="text/css" href="namemmrz.css">

</head>
<body>
	<h1>Name Memorizer</h1><br>
	<div id="blocIndex">
		<div id="connTxt">CONNEXION</div>
		<div id="formConnexion">
			<form  action='profile/personal-space.php' method='post'>
				<input type='text' name='username' placeholder='xyz@exemple.net'><br>
				<input type='password' name='password' placeholder='Mot de passe'><br>
				<input type='submit' name='connexion' value='GO'>
			</form><br>
		</div>
		<div class="cl-effect-21">
			<a href="inscription.html">INSCRIPTION</a>
		</div>
	</div>
</body>
</html>
